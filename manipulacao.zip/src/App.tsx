import './App.css';
import EventHandlingExample from './components/Event';

function App() {
    return (
        <div className='App'>
            <EventHandlingExample />
        </div>
    );
}

export default App
