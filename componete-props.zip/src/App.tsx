import React from 'react';
import './App.css';

// definindo uma interface para os props

interface WelcomeProps {
  name: string;
  age: number;
  adress: string;
  city: string;
};

// Componente funcional que utiliza os props

const Welcome: React.FC<WelcomeProps> = ({ name, age, adress, city }) => {
  return (
    < div >
      <h1>Hello, {name}!</h1>
      <p>You are {age} years old.</p>
      <p> You live in {adress}</p>
      <p> Your city is {city}</p>
    </div >
  );
};

function App() {
  return (
    <div className='App'>
      <Welcome name='Alice' age={25} adress='Rua tal' city='Paraisopolis' />
      <Welcome name='Bob' age={30} adress='Rua Major fulano' city='Xique-xique' />
      <Welcome name='Charlie' age={35} adress='Rua paris' city='Petrópolis' />
    </div>
  );
}

export default App;